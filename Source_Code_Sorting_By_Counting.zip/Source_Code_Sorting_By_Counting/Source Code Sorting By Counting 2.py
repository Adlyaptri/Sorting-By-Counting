print("===============================================")
print("==========Program Sorting By Counting==========")
print("==Program_by_22343033_Adelya Destriana Putri==")
print("===============================================")
def distribution_counting_sort(array, l, u):
    n = len(array)
    
    # Inisialisasi array D
    D = [0] * (u - l + 1)
    
    # Menghitung frekuensi kemunculan setiap elemen
    for i in range(n):
        D[array[i] - l] += 1
    
    # Menghitung distribusi kumulatif
    for j in range(1, u - l + 1):
        D[j] += D[j - 1]
    
    # Membuat array output
    output = [0] * n
    for i in range(n - 1, -1, -1):
        j = array[i] - l
        output[D[j] - 1] = array[i]
        D[j] -= 1
    
    return output

# Contoh penggunaan
arr = [4, 2, 2, 8, 3, 3, 1]
lower_limit = 1
upper_limit = 8
sorted_arr = distribution_counting_sort(arr, lower_limit, upper_limit)
print("Array setelah diurutkan:", sorted_arr)
