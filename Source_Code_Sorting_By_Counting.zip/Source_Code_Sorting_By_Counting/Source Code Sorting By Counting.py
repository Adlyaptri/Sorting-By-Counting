print("===============================================")
print("==========Program Sorting By Counting==========")
print("==Program_by_22343033_Adelya Destriana Putri==")
print("===============================================")

def counting_sort(array):
    n = len(array)
    
    # Inisialisasi array Count
    count = [0] * n
    
    # Menghitung frekuensi kemunculan setiap elemen
    for i in range(n - 1):
        for j in range(i + 1, n):
            if array[i] < array[j]:
                count[j] += 1
            else:
                count[i] += 1
    
    # Membuat array output
    output = [0] * n
    for i in range(n):
        output[count[i]] = array[i]
    
    return output

# Contoh penggunaan
arr = [4, 2, 2, 8, 3, 3, 1]
sorted_arr = counting_sort(arr)
print("Array setelah diurutkan:", sorted_arr)
